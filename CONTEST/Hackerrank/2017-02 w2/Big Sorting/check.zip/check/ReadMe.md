
Can you find any difference between in 2.cpp and bf.cpp technically?

Issue :  2.cpp is running perfectly for given input(in2.txt) and bf.txt is giving segmentation fault.

For problem statement, I have attached problem statement too.

Thanks...:)
